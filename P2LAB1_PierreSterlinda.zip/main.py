mileage = float(input())
gas_cost= float(input())

cost_20= (20/mileage)*gas_cost
cost_75= (75/mileage)*gas_cost
cost_500= (500/mileage)*gas_cost

print(f'{cost_20:.2f} {cost_75:.2f} {cost_500:.2f}')

